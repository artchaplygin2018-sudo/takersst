# TakersStudio API (v0.2)
Базовый адрес: `https://ВАШ-СЕРВЕР`. Формат JSON (camelCase). Токен доступа: `Authorization: Bearer <accessToken>` (живёт 15 минут, обновляется через refresh).

## Авторизация
| Метод | Путь | Тело | Ответ |
|---|---|---|---|
| POST | /api/auth/register | email, password(≥8), displayName? | 201 {id} |
| POST | /api/auth/login | email, password, device? {name, osVersion, appVersion} | accessToken, refreshToken, deviceId? |
| POST | /api/auth/refresh | refreshToken | новая пара токенов (старый refresh аннулируется) |
| POST | /api/auth/logout | refreshToken | 204 |
Ограничение: 10 запросов в минуту на группу /api/auth.

## Пользователь (нужен токен)
| GET /api/me | профиль, premium, premiumUntil, role, trialUsed |
| GET /api/tools | опубликованные инструменты + `locked` |
| GET /api/tools/{slug}/access | 200 {allowed:true} или 403 {reason:"premium_required"}; факт запуска пишется в журнал |
| GET /api/me/payments | история платежей |
| GET /api/me/subscription-history | **новое в 0.2**: история изменений подписки |
| GET /api/me/devices · DELETE /api/me/devices/{id} | устройства / отвязка |

## Публично
GET /api/plans · GET /api/releases/latest · GET /health

## Оплата
POST /api/payments {planId} → {paymentId, confirmationUrl}; GET /api/payments/{id} → статус (только чтение).
POST /api/payments/webhook/yookassa — для ЮKassa; статус перепроверяется запросом к API ЮKassa.

## Админ (роль Admin/Owner; проверяется на сервере)
GET /api/admin/stats · /users?q= · /users/{id} · /payments?status= · /audit?action= · /tools
POST /api/admin/users/{id}/block?blocked= · /grant {days} · /sessions/revoke · POST /tools · PUT /tools/{id} · POST /releases
Только Owner: PUT /api/admin/plans/{id} · POST /users/{id}/role · POST /users/{id}/premium-until
