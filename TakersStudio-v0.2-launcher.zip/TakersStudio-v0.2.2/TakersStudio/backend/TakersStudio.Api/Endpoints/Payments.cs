using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using TakersStudio.Api.Data;
using TakersStudio.Api.Services;
namespace TakersStudio.Api.Endpoints;

public record CreatePaymentReq(int PlanId);

public static class PaymentEndpoints {
    public static void MapPayments(this WebApplication app) {
        app.MapPost("/api/payments", async (CreatePaymentReq r, System.Security.Claims.ClaimsPrincipal p, AppDb db, YooKassa yk) => {
            var u = await db.Users.FirstAsync(x => x.Id == p.Uid());
            var plan = await db.Plans.FirstOrDefaultAsync(x => x.Id == r.PlanId && x.IsActive);
            if (plan is null) return Results.BadRequest(new { error = "Тариф не найден" });
            if (plan.IsTrial && u.TrialUsed) return Results.BadRequest(new { error = "Пробный период уже использован" });

            var pay = new Payment { UserId = u.Id, PlanId = plan.Id, AmountKopecks = plan.PriceKopecks };
            db.Payments.Add(pay);
            await db.SaveChangesAsync();
            try {
                var ykp = await yk.Create(pay.Id, pay.AmountKopecks, $"TakersStudio Premium: {plan.Name}");
                pay.ProviderPaymentId = ykp.Id;
                await db.SaveChangesAsync();
                return Results.Ok(new { paymentId = pay.Id, confirmationUrl = ykp.ConfirmationUrl });
            } catch (Exception ex) {
                pay.Status = PaymentStatus.Canceled;
                db.Audit.Add(new AuditLog { ActorId = u.Id, Action = "payment_create_failed", Target = pay.Id.ToString(), Details = ex.GetType().Name });
                await db.SaveChangesAsync();
                return Results.Json(new { error = "Платёжный сервис недоступен, попробуйте позже" }, statusCode: 502);
            }
        }).RequireAuthorization();

        // Приложение/сайт опрашивает статус. Само по себе это НИЧЕГО не активирует.
        app.MapGet("/api/payments/{id:guid}", async (Guid id, System.Security.Claims.ClaimsPrincipal p, AppDb db) => {
            var x = await db.Payments.AsNoTracking().FirstOrDefaultAsync(y => y.Id == id && y.UserId == p.Uid());
            return x is null ? Results.NotFound() : Results.Ok(new { x.Id, status = x.Status.ToString(), x.PaidAt });
        }).RequireAuthorization();

        // Webhook ЮKassa. Тело уведомления не считается доверенным: из него берём только id,
        // а статус и сумму перепроверяем запросом к API ЮKassa.
        app.MapPost("/api/payments/webhook/yookassa", async (HttpRequest req, AppDb db, YooKassa yk, ILogger<Program> log) => {
            string? providerId;
            try {
                using var doc = await JsonDocument.ParseAsync(req.Body);
                providerId = doc.RootElement.GetProperty("object").GetProperty("id").GetString();
            } catch { return Results.BadRequest(); }
            if (string.IsNullOrEmpty(providerId)) return Results.BadRequest();

            YkPayment real;
            try { real = await yk.Fetch(providerId); }
            catch (Exception ex) { log.LogError(ex, "YooKassa fetch failed"); return Results.StatusCode(500); } // ЮKassa повторит доставку

            var pay = await db.Payments.FirstOrDefaultAsync(x => x.ProviderPaymentId == providerId);
            if (pay is null || real.MetadataPaymentId != pay.Id.ToString()) return Results.Ok();   // чужой/неизвестный платёж
            if (real.Currency != "RUB" || (int)(real.Amount * 100) != pay.AmountKopecks) {
                db.Audit.Add(new AuditLog { Action = "payment_amount_mismatch", Target = pay.Id.ToString() });
                await db.SaveChangesAsync();
                return Results.Ok();
            }

            if (real.Status == "canceled") {
                await db.Payments.Where(x => x.Id == pay.Id && x.Status == PaymentStatus.Pending)
                    .ExecuteUpdateAsync(s => s.SetProperty(x => x.Status, PaymentStatus.Canceled));
                return Results.Ok();
            }
            if (real.Status != "succeeded") return Results.Ok();

            await using var tx = await db.Database.BeginTransactionAsync();
            // Атомарный переход Pending -> Succeeded: повторное уведомление затронет 0 строк (идемпотентность).
            var changed = await db.Payments.Where(x => x.Id == pay.Id && x.Status == PaymentStatus.Pending)
                .ExecuteUpdateAsync(s => s.SetProperty(x => x.Status, PaymentStatus.Succeeded).SetProperty(x => x.PaidAt, DateTime.UtcNow));
            if (changed == 1) {
                var user = await db.Users.FirstAsync(x => x.Id == pay.UserId);
                var plan = await db.Plans.AsNoTracking().FirstAsync(x => x.Id == pay.PlanId);
                Subscriptions.Extend(db, user, plan.Days, "payment", pay.Id);
                if (plan.IsTrial) user.TrialUsed = true;
                await db.SaveChangesAsync();
            }
            await tx.CommitAsync();
            return Results.Ok();
        });
    }
}
