using Microsoft.EntityFrameworkCore;
using TakersStudio.Api.Data;
using TakersStudio.Api.Services;
namespace TakersStudio.Api.Endpoints;

public static class PublicAndUserEndpoints {
    public static void MapPublicAndUser(this WebApplication app) {
        // Публично: тарифы, последняя версия приложения
        app.MapGet("/api/plans", async (AppDb db) => await db.Plans.Where(p => p.IsActive).OrderBy(p => p.SortOrder)
            .Select(p => new { p.Id, p.Name, p.Days, rub = p.PriceKopecks / 100m, p.IsTrial }).ToListAsync());

        app.MapGet("/api/releases/latest", async (AppDb db) => {
            var r = await db.Releases.Where(x => x.IsPublished).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
            return r is null ? Results.NotFound() : Results.Ok(new { r.Version, r.Changelog, r.DownloadUrl, r.Sha256, r.SizeBytes, r.CreatedAt });
        });

        var me = app.MapGroup("/api").RequireAuthorization();

        me.MapGet("/me", async (System.Security.Claims.ClaimsPrincipal p, AppDb db) => {
            var u = await db.Users.AsNoTracking().FirstAsync(x => x.Id == p.Uid());
            return new { u.Id, u.Email, u.DisplayName, role = u.Role.ToString(), premium = Subscriptions.IsPremium(u), u.PremiumUntil, u.TrialUsed };
        });

        // Каталог: клиент получает флаг locked, но реальную проверку делает сервер в /access
        me.MapGet("/tools", async (System.Security.Claims.ClaimsPrincipal p, AppDb db) => {
            var u = await db.Users.AsNoTracking().FirstAsync(x => x.Id == p.Uid());
            var prem = Subscriptions.IsPremium(u);
            var list = await db.Tools.Where(t => t.IsPublished && t.IsEnabled).OrderBy(t => t.Category).ThenBy(t => t.Name).ToListAsync();
            return list.Select(t => new { t.Slug, t.Name, t.Description, t.Category, t.Icon, t.Version, t.PremiumOnly, locked = t.PremiumOnly && !prem });
        });

        me.MapGet("/tools/{slug}/access", async (string slug, System.Security.Claims.ClaimsPrincipal p, AppDb db) => {
            var u = await db.Users.AsNoTracking().FirstAsync(x => x.Id == p.Uid());
            var t = await db.Tools.AsNoTracking().FirstOrDefaultAsync(x => x.Slug == slug && x.IsPublished && x.IsEnabled);
            if (t is null) return Results.NotFound();
            if (t.PremiumOnly && !Subscriptions.IsPremium(u)) return Results.Json(new { allowed = false, reason = "premium_required" }, statusCode: 403);
            db.Audit.Add(new AuditLog { ActorId = u.Id, Action = "tool_launch", Target = slug });
            await db.SaveChangesAsync();
            return Results.Ok(new { allowed = true });
        });

        me.MapGet("/me/payments", async (System.Security.Claims.ClaimsPrincipal p, AppDb db) =>
            await db.Payments.Where(x => x.UserId == p.Uid()).OrderByDescending(x => x.CreatedAt)
                .Select(x => new { x.Id, x.PlanId, rub = x.AmountKopecks / 100m, status = x.Status.ToString(), x.CreatedAt, x.PaidAt }).ToListAsync());

        me.MapGet("/me/subscription-history", async (System.Security.Claims.ClaimsPrincipal p, AppDb db) =>
            await db.SubscriptionEvents.Where(e => e.UserId == p.Uid()).OrderByDescending(e => e.CreatedAt).Take(100)
                .Select(e => new { e.Kind, e.Days, e.PremiumUntilAfter, e.CreatedAt }).ToListAsync());

        me.MapGet("/me/devices", async (System.Security.Claims.ClaimsPrincipal p, AppDb db) =>
            await db.Devices.Where(d => d.UserId == p.Uid() && !d.Revoked)
                .Select(d => new { d.Id, d.Name, d.OsVersion, d.AppVersion, d.LastSeen }).ToListAsync());

        me.MapDelete("/me/devices/{id:guid}", async (Guid id, System.Security.Claims.ClaimsPrincipal p, AppDb db) => {
            var n = await db.Devices.Where(d => d.Id == id && d.UserId == p.Uid()).ExecuteUpdateAsync(s => s.SetProperty(d => d.Revoked, true));
            await db.RefreshTokens.Where(r => r.DeviceId == id && r.UserId == p.Uid()).ExecuteUpdateAsync(s => s.SetProperty(r => r.Revoked, true));
            return n == 0 ? Results.NotFound() : Results.NoContent();
        });
    }
}
