using Microsoft.EntityFrameworkCore;
using TakersStudio.Api.Data;
using TakersStudio.Api.Services;
namespace TakersStudio.Api.Endpoints;

public record GrantReq(int Days);
public record SetUntilReq(DateTime? PremiumUntil);
public record RoleReq(Role Role);
public record PlanUpdateReq(string Name, int Days, decimal Rub, bool IsActive);
public record ToolReq(string Slug, string Name, string Description, string Category, string? Icon, string Version, bool PremiumOnly, bool IsPublished, bool IsEnabled);
public record ReleaseReq(string Version, string Changelog, string DownloadUrl, string Sha256, long SizeBytes, bool IsPublished);

public static class AdminEndpoints {
    static void Log(AppDb db, Guid actor, string action, string? target, string? details = null) =>
        db.Audit.Add(new AuditLog { ActorId = actor, Action = action, Target = target, Details = details });

    public static void MapAdmin(this WebApplication app) {
        var a = app.MapGroup("/api/admin").RequireAuthorization("Admin");

        a.MapGet("/stats", async (AppDb db) => {
            var now = DateTime.UtcNow;
            return new {
                users = await db.Users.CountAsync(),
                premiumActive = await db.Users.CountAsync(u => u.PremiumUntil > now),
                premiumExpired = await db.Users.CountAsync(u => u.PremiumUntil != null && u.PremiumUntil <= now),
                registrations7d = await db.Users.CountAsync(u => u.CreatedAt > now.AddDays(-7)),
                paymentsSucceeded = await db.Payments.CountAsync(p => p.Status == PaymentStatus.Succeeded),
                revenueRub = (await db.Payments.Where(p => p.Status == PaymentStatus.Succeeded).SumAsync(p => (long?)p.AmountKopecks) ?? 0) / 100m,
                devices = await db.Devices.CountAsync(d => !d.Revoked),
                toolsPublished = await db.Tools.CountAsync(t => t.IsPublished && t.IsEnabled)
            };
        });

        a.MapGet("/users", async (string? q, int? page, AppDb db) => {
            var query = db.Users.AsNoTracking().AsQueryable();
            if (!string.IsNullOrWhiteSpace(q)) {
                q = q.Trim().ToLowerInvariant();
                query = Guid.TryParse(q, out var gid) ? query.Where(u => u.Id == gid) : query.Where(u => u.Email.Contains(q));
            }
            return await query.OrderByDescending(u => u.CreatedAt).Skip((Math.Max(page ?? 1, 1) - 1) * 50).Take(50)
                .Select(u => new { u.Id, u.Email, u.DisplayName, role = u.Role.ToString(), u.IsBlocked, u.PremiumUntil, u.CreatedAt }).ToListAsync();
        });

        a.MapGet("/users/{id:guid}", async (Guid id, AppDb db) => {
            var u = await db.Users.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
            if (u is null) return Results.NotFound();
            return Results.Ok(new {
                u.Id, u.Email, u.DisplayName, role = u.Role.ToString(), u.IsBlocked, u.PremiumUntil, u.CreatedAt,
                payments = await db.Payments.Where(p => p.UserId == id).OrderByDescending(p => p.CreatedAt).Take(50).ToListAsync(),
                devices = await db.Devices.Where(d => d.UserId == id).ToListAsync(),
                subscriptionHistory = await db.SubscriptionEvents.Where(e => e.UserId == id).OrderByDescending(e => e.CreatedAt).Take(50).ToListAsync()
            });
        });

        a.MapPost("/users/{id:guid}/block", async (Guid id, bool blocked, System.Security.Claims.ClaimsPrincipal p, AppDb db) => {
            var u = await db.Users.FindAsync(id); if (u is null) return Results.NotFound();
            if (u.Role >= Role.Admin && !p.IsInRole("Owner")) return Results.Forbid();   // админов блокирует только владелец
            if (u.Id == p.Uid()) return Results.BadRequest(new { error = "Нельзя заблокировать себя" });
            u.IsBlocked = blocked;
            if (blocked) await db.RefreshTokens.Where(r => r.UserId == id).ExecuteUpdateAsync(s => s.SetProperty(r => r.Revoked, true));
            Log(db, p.Uid(), blocked ? "user_block" : "user_unblock", id.ToString());
            await db.SaveChangesAsync(); return Results.NoContent();
        });

        a.MapPost("/users/{id:guid}/grant", async (Guid id, GrantReq r, System.Security.Claims.ClaimsPrincipal p, AppDb db) => {
            if (r.Days is < 1 or > 3650) return Results.BadRequest(new { error = "Дней: 1–3650" });
            var u = await db.Users.FindAsync(id); if (u is null) return Results.NotFound();
            Subscriptions.Extend(db, u, r.Days, "admin_grant", actor: p.Uid());
            Log(db, p.Uid(), "premium_grant", id.ToString(), $"days={r.Days}");
            await db.SaveChangesAsync(); return Results.Ok(new { u.PremiumUntil });
        });

        a.MapPost("/users/{id:guid}/sessions/revoke", async (Guid id, System.Security.Claims.ClaimsPrincipal p, AppDb db) => {
            await db.RefreshTokens.Where(r => r.UserId == id).ExecuteUpdateAsync(s => s.SetProperty(r => r.Revoked, true));
            await db.Devices.Where(d => d.UserId == id).ExecuteUpdateAsync(s => s.SetProperty(d => d.Revoked, true));
            Log(db, p.Uid(), "sessions_revoke", id.ToString()); await db.SaveChangesAsync(); return Results.NoContent();
        });

        a.MapGet("/payments", async (string? status, int? page, AppDb db) => {
            var q = db.Payments.AsNoTracking().AsQueryable();
            if (Enum.TryParse<PaymentStatus>(status, true, out var s)) q = q.Where(p => p.Status == s);
            return await q.OrderByDescending(p => p.CreatedAt).Skip((Math.Max(page ?? 1, 1) - 1) * 50).Take(50).ToListAsync();
        });

        a.MapGet("/audit", async (string? action, int? page, AppDb db) => {
            var q = db.Audit.AsNoTracking().AsQueryable();
            if (!string.IsNullOrWhiteSpace(action)) q = q.Where(x => x.Action == action);
            return await q.OrderByDescending(x => x.Id).Skip((Math.Max(page ?? 1, 1) - 1) * 100).Take(100).ToListAsync();
        });

        // Инструменты
        a.MapGet("/tools", async (AppDb db) => await db.Tools.AsNoTracking().OrderBy(t => t.Category).ToListAsync());
        a.MapPost("/tools", async (ToolReq r, System.Security.Claims.ClaimsPrincipal p, AppDb db) => {
            if (await db.Tools.AnyAsync(t => t.Slug == r.Slug)) return Results.Conflict(new { error = "Slug занят" });
            var t = new Tool { Slug = r.Slug, Name = r.Name, Description = r.Description, Category = r.Category, Icon = r.Icon, Version = r.Version, PremiumOnly = r.PremiumOnly, IsPublished = r.IsPublished, IsEnabled = r.IsEnabled };
            db.Tools.Add(t); Log(db, p.Uid(), "tool_create", r.Slug); await db.SaveChangesAsync(); return Results.Created($"/api/admin/tools/{t.Id}", t);
        });
        a.MapPut("/tools/{id:int}", async (int id, ToolReq r, System.Security.Claims.ClaimsPrincipal p, AppDb db) => {
            var t = await db.Tools.FindAsync(id); if (t is null) return Results.NotFound();
            t.Name = r.Name; t.Description = r.Description; t.Category = r.Category; t.Icon = r.Icon; t.Version = r.Version;
            t.PremiumOnly = r.PremiumOnly; t.IsPublished = r.IsPublished; t.IsEnabled = r.IsEnabled;
            Log(db, p.Uid(), "tool_update", t.Slug); await db.SaveChangesAsync(); return Results.Ok(t);
        });

        // Релизы приложения
        a.MapPost("/releases", async (ReleaseReq r, System.Security.Claims.ClaimsPrincipal p, AppDb db) => {
            db.Releases.Add(new AppRelease { Version = r.Version, Changelog = r.Changelog, DownloadUrl = r.DownloadUrl, Sha256 = r.Sha256.ToUpperInvariant(), SizeBytes = r.SizeBytes, IsPublished = r.IsPublished });
            Log(db, p.Uid(), "release_create", r.Version); await db.SaveChangesAsync(); return Results.Created("/api/releases/latest", null);
        });

        // Только владелец: тарифы, роли, ручная установка даты
        var o = app.MapGroup("/api/admin").RequireAuthorization("Owner");
        o.MapPut("/plans/{id:int}", async (int id, PlanUpdateReq r, System.Security.Claims.ClaimsPrincipal p, AppDb db) => {
            if (r.Days < 1 || r.Rub <= 0) return Results.BadRequest();
            var pl = await db.Plans.FindAsync(id); if (pl is null) return Results.NotFound();
            pl.Name = r.Name; pl.Days = r.Days; pl.PriceKopecks = (int)(r.Rub * 100); pl.IsActive = r.IsActive;
            Log(db, p.Uid(), "plan_update", id.ToString(), $"days={r.Days};rub={r.Rub}"); await db.SaveChangesAsync(); return Results.NoContent();
        });
        o.MapPost("/users/{id:guid}/role", async (Guid id, RoleReq r, System.Security.Claims.ClaimsPrincipal p, AppDb db) => {
            if (id == p.Uid()) return Results.BadRequest(new { error = "Нельзя менять свою роль" });
            var u = await db.Users.FindAsync(id); if (u is null) return Results.NotFound();
            u.Role = r.Role;
            await db.RefreshTokens.Where(x => x.UserId == id).ExecuteUpdateAsync(s => s.SetProperty(x => x.Revoked, true)); // новая роль = новый вход
            Log(db, p.Uid(), "role_change", id.ToString(), r.Role.ToString()); await db.SaveChangesAsync(); return Results.NoContent();
        });
        o.MapPost("/users/{id:guid}/premium-until", async (Guid id, SetUntilReq r, System.Security.Claims.ClaimsPrincipal p, AppDb db) => {
            var u = await db.Users.FindAsync(id); if (u is null) return Results.NotFound();
            u.PremiumUntil = r.PremiumUntil?.ToUniversalTime();
            db.SubscriptionEvents.Add(new SubscriptionEvent { UserId = id, Kind = "admin_set", ActorId = p.Uid(), PremiumUntilAfter = u.PremiumUntil });
            Log(db, p.Uid(), "premium_set", id.ToString()); await db.SaveChangesAsync(); return Results.NoContent();
        });
    }
}
