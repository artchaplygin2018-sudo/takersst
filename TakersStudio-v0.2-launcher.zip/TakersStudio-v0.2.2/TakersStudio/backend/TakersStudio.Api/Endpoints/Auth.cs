using System.Net.Mail;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using TakersStudio.Api.Data;
using TakersStudio.Api.Services;
namespace TakersStudio.Api.Endpoints;

public record RegisterReq(string Email, string Password, string? DisplayName);
public record DeviceInfo(string Name, string OsVersion, string AppVersion);
public record LoginReq(string Email, string Password, DeviceInfo? Device);
public record RefreshReq(string RefreshToken);

public static class AuthEndpoints {
    static bool ValidEmail(string e) { try { return new MailAddress(e).Address == e && e.Length <= 254; } catch { return false; } }
    public static Guid Uid(this ClaimsPrincipal p) => Guid.Parse(p.FindFirstValue("sub")!);

    public static void MapAuth(this WebApplication app) {
        var g = app.MapGroup("/api/auth").RequireRateLimiting("auth");

        g.MapPost("/register", async (RegisterReq r, AppDb db) => {
            var email = (r.Email ?? "").Trim().ToLowerInvariant();
            if (!ValidEmail(email)) return Results.BadRequest(new { error = "Некорректная почта" });
            if ((r.Password ?? "").Length < 8) return Results.BadRequest(new { error = "Пароль минимум 8 символов" });
            if (await db.Users.AnyAsync(u => u.Email == email)) return Results.Conflict(new { error = "Почта уже занята" });
            var u = new User { Email = email, DisplayName = r.DisplayName?.Trim(), PasswordHash = BCrypt.Net.BCrypt.HashPassword(r.Password) };
            db.Users.Add(u);
            db.Audit.Add(new AuditLog { ActorId = u.Id, Action = "register", Target = u.Id.ToString() });
            await db.SaveChangesAsync();
            return Results.Created($"/api/me", new { u.Id });
        });

        g.MapPost("/login", async (LoginReq r, AppDb db, Tokens t) => {
            var email = (r.Email ?? "").Trim().ToLowerInvariant();
            var u = await db.Users.FirstOrDefaultAsync(x => x.Email == email);
            if (u is null || !BCrypt.Net.BCrypt.Verify(r.Password ?? "", u.PasswordHash))
                return Results.Json(new { error = "Неверная почта или пароль" }, statusCode: 401);
            if (u.IsBlocked) return Results.Json(new { error = "Аккаунт заблокирован" }, statusCode: 403);
            Device? dev = null;
            if (r.Device is { } d) {
                dev = new Device { UserId = u.Id, Name = d.Name[..Math.Min(d.Name.Length, 100)], OsVersion = d.OsVersion, AppVersion = d.AppVersion };
                db.Devices.Add(dev);
            }
            var refresh = Tokens.NewRefresh();
            db.RefreshTokens.Add(new RefreshToken { UserId = u.Id, DeviceId = dev?.Id, TokenHash = Tokens.Hash(refresh), ExpiresAt = DateTime.UtcNow.AddDays(30) });
            db.Audit.Add(new AuditLog { ActorId = u.Id, Action = "login", Target = dev?.Id.ToString() });
            await db.SaveChangesAsync();
            return Results.Ok(new { accessToken = t.Access(u, dev?.Id), refreshToken = refresh, deviceId = dev?.Id });
        });

        g.MapPost("/refresh", async (RefreshReq r, AppDb db, Tokens t) => {
            var h = Tokens.Hash(r.RefreshToken ?? "");
            var rt = await db.RefreshTokens.FirstOrDefaultAsync(x => x.TokenHash == h);
            if (rt is null || rt.Revoked || rt.ExpiresAt < DateTime.UtcNow) return Results.Unauthorized();
            var u = await db.Users.FindAsync(rt.UserId);
            if (u is null || u.IsBlocked) return Results.Unauthorized();
            if (rt.DeviceId != null && await db.Devices.AnyAsync(d => d.Id == rt.DeviceId && d.Revoked)) return Results.Unauthorized();
            rt.Revoked = true;   // ротация: старый токен больше не действует
            var next = Tokens.NewRefresh();
            db.RefreshTokens.Add(new RefreshToken { UserId = u.Id, DeviceId = rt.DeviceId, TokenHash = Tokens.Hash(next), ExpiresAt = DateTime.UtcNow.AddDays(30) });
            await db.SaveChangesAsync();
            return Results.Ok(new { accessToken = t.Access(u, rt.DeviceId), refreshToken = next });
        });

        g.MapPost("/logout", async (RefreshReq r, AppDb db) => {
            var h = Tokens.Hash(r.RefreshToken ?? "");
            await db.RefreshTokens.Where(x => x.TokenHash == h).ExecuteUpdateAsync(s => s.SetProperty(x => x.Revoked, true));
            return Results.NoContent();
        });
    }
}
