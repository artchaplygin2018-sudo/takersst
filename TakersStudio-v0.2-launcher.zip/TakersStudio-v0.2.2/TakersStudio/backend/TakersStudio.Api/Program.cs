using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using TakersStudio.Api.Data;
using TakersStudio.Api.Endpoints;
using TakersStudio.Api.Services;

var builder = WebApplication.CreateBuilder(args);
builder.Configuration.AddEnvironmentVariables();   // секреты передавать через переменные окружения

var jwtKey = builder.Configuration["Jwt:Key"];
if (string.IsNullOrWhiteSpace(jwtKey) || jwtKey.Length < 32)
    throw new InvalidOperationException("Задайте Jwt__Key (минимум 32 символа) в переменных окружения.");

builder.Services.AddDbContext<AppDb>(o => o.UseNpgsql(builder.Configuration.GetConnectionString("Db")));
builder.Services.AddSingleton<Tokens>();
builder.Services.AddHttpClient<YooKassa>();
builder.Services.AddCors(o => o.AddDefaultPolicy(p => p
    .WithOrigins(builder.Configuration.GetSection("Cors:Origins").Get<string[]>() ?? [])
    .AllowAnyHeader().AllowAnyMethod()));
builder.Services.AddRateLimiter(o => {
    o.RejectionStatusCode = 429;
    o.AddFixedWindowLimiter("auth", c => { c.PermitLimit = 10; c.Window = TimeSpan.FromMinutes(1); });
});
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(o => {
    o.TokenValidationParameters = new TokenValidationParameters {
        ValidIssuer = builder.Configuration["Jwt:Issuer"], ValidAudience = builder.Configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
        ClockSkew = TimeSpan.FromSeconds(30), NameClaimType = ClaimTypes.NameIdentifier
    };
    o.MapInboundClaims = false;
    // Блокировка аккаунта и отзыв устройства действуют сразу, а не через 15 минут.
    o.Events = new JwtBearerEvents {
        OnTokenValidated = async ctx => {
            var db = ctx.HttpContext.RequestServices.GetRequiredService<AppDb>();
            var uid = Guid.Parse(ctx.Principal!.FindFirstValue("sub")!);
            var u = await db.Users.AsNoTracking().FirstOrDefaultAsync(x => x.Id == uid);
            var did = ctx.Principal.FindFirstValue("did");
            var devBad = did != null && await db.Devices.AnyAsync(d => d.Id == Guid.Parse(did) && d.Revoked);
            if (u is null || u.IsBlocked || devBad) ctx.Fail("blocked");
            else if (did != null) await db.Devices.Where(d => d.Id == Guid.Parse(did))
                .ExecuteUpdateAsync(s => s.SetProperty(d => d.LastSeen, DateTime.UtcNow));
        }
    };
});
builder.Services.AddAuthorizationBuilder()
    .AddPolicy("Moderator", p => p.RequireRole("Moderator", "Admin", "Owner"))
    .AddPolicy("Admin", p => p.RequireRole("Admin", "Owner"))
    .AddPolicy("Owner", p => p.RequireRole("Owner"));

var app = builder.Build();

using (var scope = app.Services.CreateScope()) {
    var db = scope.ServiceProvider.GetRequiredService<AppDb>();
    await db.Database.EnsureCreatedAsync();   // v1: схема создаётся автоматически; для продакшена перейти на миграции (dotnet ef)
    var email = app.Configuration["Bootstrap:OwnerEmail"]?.Trim().ToLowerInvariant();
    var pass = app.Configuration["Bootstrap:OwnerPassword"];
    if (!string.IsNullOrEmpty(email) && !string.IsNullOrEmpty(pass) && !await db.Users.AnyAsync(u => u.Role == Role.Owner)) {
        db.Users.Add(new User { Email = email, PasswordHash = BCrypt.Net.BCrypt.HashPassword(pass), Role = Role.Owner });
        await db.SaveChangesAsync();
    }
}

app.UseCors();
app.UseRateLimiter();
app.UseAuthentication();
app.UseAuthorization();

app.MapGet("/health", () => Results.Ok(new { ok = true }));
app.MapAuth();
app.MapPublicAndUser();
app.MapPayments();
app.MapAdmin();
app.Run();
