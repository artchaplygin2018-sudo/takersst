using TakersStudio.Api.Data;
namespace TakersStudio.Api.Services;

public static class Subscriptions {
    public static bool IsPremium(User u) => u.PremiumUntil is { } t && t > DateTime.UtcNow;

    /// Продлевает от текущего окончания (если активна) или от «сейчас». Вызывать внутри транзакции.
    public static void Extend(AppDb db, User u, int days, string kind, Guid? paymentId = null, Guid? actor = null) {
        var from = IsPremium(u) ? u.PremiumUntil!.Value : DateTime.UtcNow;
        u.PremiumUntil = from.AddDays(days);
        db.SubscriptionEvents.Add(new SubscriptionEvent {
            UserId = u.Id, Kind = kind, Days = days, PaymentId = paymentId,
            ActorId = actor, PremiumUntilAfter = u.PremiumUntil });
    }
}
