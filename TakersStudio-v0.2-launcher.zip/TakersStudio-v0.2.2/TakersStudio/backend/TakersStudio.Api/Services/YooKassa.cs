using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
namespace TakersStudio.Api.Services;

public record YkPayment(string Id, string Status, decimal Amount, string Currency, string? ConfirmationUrl, string? MetadataPaymentId);

public class YooKassa(HttpClient http, IConfiguration cfg) {
    void Auth() {
        var raw = $"{cfg["YooKassa:ShopId"]}:{cfg["YooKassa:SecretKey"]}";
        http.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Basic", Convert.ToBase64String(Encoding.UTF8.GetBytes(raw)));
    }
    public async Task<YkPayment> Create(Guid paymentId, int kopecks, string description) {
        Auth();
        var body = JsonSerializer.Serialize(new {
            amount = new { value = (kopecks / 100m).ToString("0.00", System.Globalization.CultureInfo.InvariantCulture), currency = "RUB" },
            capture = true,
            confirmation = new { type = "redirect", return_url = cfg["YooKassa:ReturnUrl"] },
            description,
            metadata = new { payment_id = paymentId.ToString() }
        });
        var req = new HttpRequestMessage(HttpMethod.Post, "https://api.yookassa.ru/v3/payments") {
            Content = new StringContent(body, Encoding.UTF8, "application/json") };
        req.Headers.Add("Idempotence-Key", paymentId.ToString());   // повтор запроса не создаст дубль
        var res = await http.SendAsync(req);
        res.EnsureSuccessStatusCode();
        return Parse(await res.Content.ReadAsStringAsync());
    }
    /// Источник правды: статус берём из API ЮKassa, а не из тела входящего уведомления.
    public async Task<YkPayment> Fetch(string providerId) {
        Auth();
        var res = await http.GetAsync($"https://api.yookassa.ru/v3/payments/{Uri.EscapeDataString(providerId)}");
        res.EnsureSuccessStatusCode();
        return Parse(await res.Content.ReadAsStringAsync());
    }
    static YkPayment Parse(string json) {
        var r = JsonDocument.Parse(json).RootElement;
        string? url = r.TryGetProperty("confirmation", out var c) && c.TryGetProperty("confirmation_url", out var u) ? u.GetString() : null;
        string? meta = r.TryGetProperty("metadata", out var m) && m.TryGetProperty("payment_id", out var p) ? p.GetString() : null;
        var amt = r.GetProperty("amount");
        return new(r.GetProperty("id").GetString()!, r.GetProperty("status").GetString()!,
            decimal.Parse(amt.GetProperty("value").GetString()!, System.Globalization.CultureInfo.InvariantCulture),
            amt.GetProperty("currency").GetString()!, url, meta);
    }
}
