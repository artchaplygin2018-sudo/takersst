namespace TakersStudio.Api.Data;

public enum Role { User = 0, Moderator = 1, Admin = 2, Owner = 3 }
public enum PaymentStatus { Pending, Succeeded, Canceled, Refunded }

public class User {
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Email { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string? DisplayName { get; set; }
    public Role Role { get; set; } = Role.User;
    public bool IsBlocked { get; set; }
    public bool TrialUsed { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? PremiumUntil { get; set; }   // единый источник правды о подписке
}
public class Plan {
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public int Days { get; set; }
    public int PriceKopecks { get; set; }
    public bool IsTrial { get; set; }
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }
}
public class Payment {
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid UserId { get; set; }
    public int PlanId { get; set; }
    public int AmountKopecks { get; set; }
    public string? ProviderPaymentId { get; set; }
    public PaymentStatus Status { get; set; } = PaymentStatus.Pending;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? PaidAt { get; set; }
}
public class SubscriptionEvent {
    public long Id { get; set; }
    public Guid UserId { get; set; }
    public string Kind { get; set; } = "";      // payment | admin_grant | admin_set
    public int? Days { get; set; }
    public Guid? PaymentId { get; set; }
    public Guid? ActorId { get; set; }
    public DateTime? PremiumUntilAfter { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
public class RefreshToken {
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid UserId { get; set; }
    public Guid? DeviceId { get; set; }
    public string TokenHash { get; set; } = "";
    public DateTime ExpiresAt { get; set; }
    public bool Revoked { get; set; }
}
public class Device {
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid UserId { get; set; }
    public string Name { get; set; } = "";
    public string OsVersion { get; set; } = "";
    public string AppVersion { get; set; } = "";
    public bool Revoked { get; set; }
    public DateTime LastSeen { get; set; } = DateTime.UtcNow;
}
public class Tool {
    public int Id { get; set; }
    public string Slug { get; set; } = "";
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public string Category { get; set; } = "";   // farm|jobs|leveling|club|faction|utils
    public string? Icon { get; set; }
    public string Version { get; set; } = "0.0.0";
    public bool PremiumOnly { get; set; } = true;
    public bool IsPublished { get; set; }
    public bool IsEnabled { get; set; } = true;
}
public class AppRelease {
    public int Id { get; set; }
    public string Version { get; set; } = "";
    public string Changelog { get; set; } = "";
    public string DownloadUrl { get; set; } = "";
    public string Sha256 { get; set; } = "";
    public long SizeBytes { get; set; }
    public bool IsPublished { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
public class AuditLog {
    public long Id { get; set; }
    public Guid? ActorId { get; set; }
    public string Action { get; set; } = "";
    public string? Target { get; set; }
    public string? Details { get; set; }   // никогда не писать пароли, токены, платёжные данные
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
