using Microsoft.EntityFrameworkCore;
namespace TakersStudio.Api.Data;

public class AppDb(DbContextOptions<AppDb> o) : DbContext(o) {
    public DbSet<User> Users => Set<User>();
    public DbSet<Plan> Plans => Set<Plan>();
    public DbSet<Payment> Payments => Set<Payment>();
    public DbSet<SubscriptionEvent> SubscriptionEvents => Set<SubscriptionEvent>();
    public DbSet<RefreshToken> RefreshTokens => Set<RefreshToken>();
    public DbSet<Device> Devices => Set<Device>();
    public DbSet<Tool> Tools => Set<Tool>();
    public DbSet<AppRelease> Releases => Set<AppRelease>();
    public DbSet<AuditLog> Audit => Set<AuditLog>();

    protected override void OnModelCreating(ModelBuilder b) {
        b.Entity<User>().HasIndex(x => x.Email).IsUnique();
        b.Entity<Tool>().HasIndex(x => x.Slug).IsUnique();
        b.Entity<Payment>().HasIndex(x => x.ProviderPaymentId).IsUnique();
        b.Entity<Plan>().HasData(
            new Plan { Id = 1, Name = "Пробный · 3 дня", Days = 3,   PriceKopecks = 8000,   IsTrial = true, SortOrder = 1 },
            new Plan { Id = 2, Name = "Неделя",          Days = 7,   PriceKopecks = 14900,  SortOrder = 2 },
            new Plan { Id = 3, Name = "Месяц",           Days = 30,  PriceKopecks = 29900,  SortOrder = 3 },
            new Plan { Id = 4, Name = "Полгода",         Days = 180, PriceKopecks = 149000, SortOrder = 4 },
            new Plan { Id = 5, Name = "Год",             Days = 365, PriceKopecks = 249000, SortOrder = 5 });
    }
}
