using System.Windows.Controls;
namespace TakersStudio.Launcher.Views;
public partial class LogsView : UserControl { public LogsView() { InitializeComponent(); } }
