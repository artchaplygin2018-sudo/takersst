using System.Windows.Controls;
namespace TakersStudio.Launcher.Views;
public partial class SettingsView : UserControl { public SettingsView() { InitializeComponent(); } }
