using System.Windows.Controls;
namespace TakersStudio.Launcher.Views;
public partial class AccountView : UserControl { public AccountView() { InitializeComponent(); } }
