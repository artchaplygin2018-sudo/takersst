using System.Windows.Controls;
namespace TakersStudio.Launcher.Views;
public partial class AdminView : UserControl { public AdminView() { InitializeComponent(); } }
