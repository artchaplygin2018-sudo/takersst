using System.Windows.Controls;
namespace TakersStudio.Launcher.Views;
public partial class HomeView : UserControl { public HomeView() { InitializeComponent(); } }
