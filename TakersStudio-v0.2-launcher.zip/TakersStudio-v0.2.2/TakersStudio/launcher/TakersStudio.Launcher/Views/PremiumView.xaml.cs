using System.Windows.Controls;
namespace TakersStudio.Launcher.Views;
public partial class PremiumView : UserControl { public PremiumView() { InitializeComponent(); } }
