using System.Windows;
using System.Windows.Controls;
using TakersStudio.Launcher.ViewModels;
namespace TakersStudio.Launcher.Views;

public partial class AuthView : UserControl {
    public AuthView() {
        InitializeComponent();
        DataContextChanged += (_, e) => { if (e.NewValue is AuthVm vm) vm.ClearPasswords += () => { Pw.Clear(); Pw2.Clear(); }; };
    }
    void Pw_Changed(object s, RoutedEventArgs e) { if (DataContext is AuthVm vm) vm.Password = Pw.Password; }
    void Pw2_Changed(object s, RoutedEventArgs e) { if (DataContext is AuthVm vm) vm.Password2 = Pw2.Password; }
}
