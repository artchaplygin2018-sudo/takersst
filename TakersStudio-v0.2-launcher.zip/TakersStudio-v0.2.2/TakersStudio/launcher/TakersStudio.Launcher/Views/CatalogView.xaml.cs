using System.Windows.Controls;
namespace TakersStudio.Launcher.Views;
public partial class CatalogView : UserControl { public CatalogView() { InitializeComponent(); } }
