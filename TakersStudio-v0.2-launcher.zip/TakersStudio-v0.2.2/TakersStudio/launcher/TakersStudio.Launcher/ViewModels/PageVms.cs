using System.Collections.ObjectModel;
using System.Diagnostics;
using TakersStudio.Launcher.Core;
using TakersStudio.Sdk;
namespace TakersStudio.Launcher.ViewModels;

public class HomeVm(MainVm main) : ObservableObject {
    public MainVm Main { get; } = main;
    public string RunningText => Main.Catalog == null ? "" : $"Запущено инструментов: {Main.Catalog.RunningCount}";
    public void RefreshRunning() => Raise(nameof(RunningText));
}

public class ToolCardVm : ObservableObject {
    readonly ToolDto _d; readonly IToolModule? _m; CancellationTokenSource? _cts; ToolState _state = ToolState.Stopped;
    public event Action? Changed;
    public ToolCardVm(ToolDto d, IToolModule? m) {
        _d = d; _m = m;
        if (m != null) m.StateChanged += s => System.Windows.Application.Current.Dispatcher.Invoke(() => { State = s; });
        StartCommand = new RelayCommand(async _ => await Start(), _ => CanStart);
        StopCommand = new RelayCommand(async _ => await Stop(), _ => CanStop);
    }
    public ToolDto Dto => _d;
    public string Name => _d.Name; public string Description => _d.Description; public string Version => _d.Version;
    public string CategoryTitle => CatalogVm.CategoryName(_d.Category);
    public bool PremiumOnly => _d.PremiumOnly;
    public bool HasModule => _m != null;
    public ToolState State { get => _state; set { Set(ref _state, value); Raise(nameof(StateText)); Raise(nameof(CanStart)); Raise(nameof(CanStop)); Raise(nameof(IsRunning)); StartCommand.Notify(); StopCommand.Notify(); Changed?.Invoke(); } }
    public bool IsRunning => State is ToolState.Running or ToolState.Starting;
    public bool CanStart => HasModule && State is ToolState.Stopped or ToolState.Error;
    public bool CanStop => HasModule && IsRunning;
    public string StateText => !HasModule ? "Модуль не установлен"
        : _d.Locked && State == ToolState.Stopped ? "Нужен Premium"
        : State switch { ToolState.Running => "Работает", ToolState.Starting => "Запускается…", ToolState.Error => "Ошибка", _ => "Остановлен" };
    public RelayCommand StartCommand { get; }
    public RelayCommand StopCommand { get; }

    async Task Start() {
        try { await Services.Api.ToolAccess(_d.Slug); }   // решение о доступе принимает сервер
        catch (ApiException e) when (e.Status == 403) { Services.Notify.Show("Для этого инструмента нужен активный Premium.", true); return; }
        _cts = new CancellationTokenSource();
        Services.Log.Info($"Запуск инструмента {_d.Slug}");
        try { await _m!.StartAsync(new ToolContext(_d.Slug), _cts.Token); }
        catch (Exception ex) { Services.Log.Error($"{_d.Slug}: {ex.Message}"); State = ToolState.Error; Services.Notify.Show($"{_d.Name}: {ex.Message}", true); }
    }
    async Task Stop() {
        try { _cts?.Cancel(); await _m!.StopAsync(); Services.Log.Info($"Остановлен {_d.Slug}"); }
        catch (Exception ex) { Services.Log.Error($"{_d.Slug}: {ex.Message}"); Services.Notify.Show($"Не удалось остановить: {ex.Message}", true); }
    }
}

public class CatalogVm : ObservableObject {
    readonly MainVm _main; List<ToolCardVm> _all = new(); string _cat = "all";
    public static string CategoryName(string c) => c switch {
        "farm" => "Фарм", "jobs" => "Работы", "leveling" => "Прокачка", "club" => "Клубные инструменты",
        "faction" => "Фракционные инструменты", "utils" => "Утилиты", _ => c };
    public record CatItem(string Key, string Title);
    public List<CatItem> Categories { get; } = new[] { new CatItem("all", "Все") }
        .Concat(new[] { "farm", "jobs", "leveling", "club", "faction", "utils" }.Select(k => new CatItem(k, CategoryName(k)))).ToList();
    public ObservableCollection<ToolCardVm> Tools { get; } = new();
    public CatalogVm(MainVm m) { _main = m; }
    public string SelectedCategory { get => _cat; set { if (Set(ref _cat, value)) Filter(); } }
    public int RunningCount => _all.Count(t => t.IsRunning);
    public bool IsEmpty => Tools.Count == 0;
    public string EmptyText => _all.Count == 0
        ? "Каталог пока пуст. Инструменты появятся здесь после публикации в админ-панели."
        : "В этой категории пока нет инструментов.";

    public async Task Load() {
        var list = await Services.Api.Tools();
        foreach (var old in _all.Where(o => o.IsRunning)) { /* работающие карточки сохраняем */ }
        var running = _all.Where(o => o.IsRunning).ToDictionary(o => o.Dto.Slug);
        _all = list.Select(d => running.TryGetValue(d.Slug, out var r) ? r : Make(d)).ToList();
        Filter();
    }
    ToolCardVm Make(ToolDto d) { var c = new ToolCardVm(d, Services.Host.Find(d.Slug)); c.Changed += () => _main.Home?.RefreshRunning(); return c; }
    void Filter() {
        Tools.Clear();
        foreach (var t in _all.Where(t => _cat == "all" || t.Dto.Category == _cat)) Tools.Add(t);
        Raise(nameof(IsEmpty)); Raise(nameof(EmptyText)); _main.Home?.RefreshRunning();
    }
}

public class PremiumVm : ObservableObject {
    readonly MainVm _main; string _status = ""; bool _waiting; CancellationTokenSource? _pollCts;
    public ObservableCollection<PlanDto> Plans { get; } = new();
    public ObservableCollection<PaymentDto> Payments { get; } = new();
    public PremiumVm(MainVm m) {
        _main = m;
        BuyCommand = new RelayCommand(async p => await Buy((PlanDto)p!), _ => !Waiting);
        CancelWaitCommand = new RelayCommand(_ => { _pollCts?.Cancel(); });
    }
    public MainVm Main => _main;
    public string Status { get => _status; set => Set(ref _status, value); }
    public bool Waiting { get => _waiting; set { Set(ref _waiting, value); BuyCommand.Notify(); } }
    public RelayCommand BuyCommand { get; }
    public RelayCommand CancelWaitCommand { get; }

    public async Task Load() {
        var plans = await Services.Api.Plans();
        Plans.Clear(); foreach (var p in plans) Plans.Add(p);
        var pay = await Services.Api.Payments();
        Payments.Clear(); foreach (var p in pay) Payments.Add(p);
        await _main.RefreshMe();
    }

    async Task Buy(PlanDto plan) {
        if (plan.IsTrial && _main.Me!.TrialUsed) { Services.Notify.Show("Пробный период уже использован.", true); return; }
        var r = await Services.Api.CreatePayment(plan.Id);
        if (r.ConfirmationUrl is not { } url || !Uri.TryCreate(url, UriKind.Absolute, out var u) || u.Scheme != Uri.UriSchemeHttps)
            throw new InvalidOperationException("Сервер не вернул безопасную ссылку на оплату.");
        Services.Log.Info($"Создан платёж {r.PaymentId} (тариф {plan.Id})");
        Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
        Status = "Страница оплаты открыта в браузере. После оплаты статус обновится автоматически.";
        _ = Poll(r.PaymentId);
    }

    // Приложение только СПРАШИВАЕТ сервер о статусе. Premium включает исключительно Backend по подтверждению ЮKassa.
    async Task Poll(Guid id) {
        _pollCts = new CancellationTokenSource(TimeSpan.FromMinutes(15)); Waiting = true;
        try {
            while (!_pollCts.IsCancellationRequested) {
                await Task.Delay(4000, _pollCts.Token);
                var s = await Services.Api.PaymentStatus(id);
                if (s.Status == "Succeeded") { await _main.RefreshMe(); Status = "Оплата подтверждена. Premium активирован."; Services.Notify.Show("Оплата прошла, Premium активен"); await Load(); return; }
                if (s.Status is "Canceled" or "Refunded") { Status = "Платёж отменён."; Services.Notify.Show("Платёж не прошёл", true); return; }
            }
        } catch (OperationCanceledException) { Status = "Ожидание остановлено. Если вы оплатили, статус обновится при следующей проверке."; }
        catch (Exception ex) { Errors.Handle(ex); }
        finally { Waiting = false; }
    }
}

public class AccountVm : ObservableObject {
    readonly MainVm _main;
    public MainVm Main => _main;
    public ObservableCollection<DeviceDto> Devices { get; } = new();
    public ObservableCollection<PaymentDto> Payments { get; } = new();
    public ObservableCollection<SubEventDto> History { get; } = new();
    public Guid? CurrentDevice => Services.Api.CurrentDeviceId;
    public AccountVm(MainVm m) {
        _main = m;
        RevokeCommand = new RelayCommand(async p => {
            var d = (DeviceDto)p!;
            if (d.Id == CurrentDevice) { Services.Notify.Show("Это текущее устройство. Для выхода нажмите «Выйти».", true); return; }
            await Services.Api.RevokeDevice(d.Id); Services.Notify.Show("Устройство отвязано"); await Load();
        });
    }
    public RelayCommand RevokeCommand { get; }
    public async Task Load() {
        await _main.RefreshMe();
        Fill(Devices, await Services.Api.Devices()); Fill(Payments, await Services.Api.Payments()); Fill(History, await Services.Api.SubscriptionHistory());
    }
    static void Fill<T>(ObservableCollection<T> c, IEnumerable<T> items) { c.Clear(); foreach (var i in items) c.Add(i); }
}

public class SettingsVm : ObservableObject {
    readonly MainVm _main; string _url;
    public SettingsVm(MainVm m) {
        _main = m; _url = Services.Settings.ApiBaseUrl;
        SaveCommand = new RelayCommand(async _ => await Save());
        CheckUpdateCommand = new RelayCommand(async _ => await _main.CheckUpdate(true));
        OpenLogsCommand = new RelayCommand(_ => Open(Path.Combine(Services.DataDir, "logs")));
        OpenModulesCommand = new RelayCommand(_ => Open(Services.Host.ModulesDir));
    }
    public string ApiUrl { get => _url; set => Set(ref _url, value); }
    public bool CheckUpdates { get => Services.Settings.CheckUpdates; set { Services.Settings.CheckUpdates = value; Services.Settings.Save(); Raise(); } }
    public bool Notifications { get => Services.Settings.Notifications; set { Services.Settings.Notifications = value; Services.Settings.Save(); Raise(); } }
    public string VersionText => $"TakersStudio Launcher {Services.AppVersion}";
    public string ModulesText => $"Модулей установлено: {Services.Host.Modules.Count}";
    public RelayCommand SaveCommand { get; } public RelayCommand CheckUpdateCommand { get; }
    public RelayCommand OpenLogsCommand { get; } public RelayCommand OpenModulesCommand { get; }
    static void Open(string dir) { Directory.CreateDirectory(dir); Process.Start(new ProcessStartInfo(dir) { UseShellExecute = true }); }
    async Task Save() {
        if (!Uri.TryCreate(ApiUrl.Trim(), UriKind.Absolute, out var u) || (u.Scheme != "https" && !u.IsLoopback))
            throw new InvalidOperationException("Адрес сервера должен начинаться с https:// (http:// разрешён только для localhost).");
        if (u.ToString().TrimEnd('/') == Services.Settings.ApiBaseUrl.TrimEnd('/')) { Services.Notify.Show("Без изменений"); return; }
        Services.Settings.ApiBaseUrl = ApiUrl.Trim().TrimEnd('/'); Services.Settings.Save();
        await _main.Logout();   // другой сервер — другая сессия
        Services.Api.SetBaseUrl(Services.Settings.ApiBaseUrl);
        Services.Notify.Show("Адрес сохранён. Войдите заново.");
    }
}

public class LogsVm : ObservableObject {
    public ObservableCollection<string> Lines => Services.Log.Lines;
}

public class AdminVm : ObservableObject {
    readonly MainVm _main; string _query = "", _grantDays = "30"; AdminStatsDto? _stats; AdminUserDto? _sel;
    public AdminVm(MainVm m) {
        _main = m;
        SearchCommand = new RelayCommand(async _ => await Search());
        BlockCommand = new RelayCommand(async _ => { await Services.Api.AdminBlock(Selected!.Id, !Selected.IsBlocked); await Search(); }, _ => Selected != null);
        GrantCommand = new RelayCommand(async _ => {
            if (!int.TryParse(GrantDays, out var d) || d < 1) throw new InvalidOperationException("Укажите число дней");
            await Services.Api.AdminGrant(Selected!.Id, d); Services.Notify.Show($"Выдано {d} дн. Premium"); await Search();
        }, _ => Selected != null);
    }
    public ObservableCollection<AdminUserDto> Users { get; } = new();
    public ObservableCollection<AuditDto> Audit { get; } = new();
    public AdminStatsDto? Stats { get => _stats; set { Set(ref _stats, value); Raise(nameof(StatsText)); } }
    public string StatsText => Stats == null ? "" :
        $"Пользователей: {Stats.Users} · Premium: {Stats.PremiumActive} · Истекло: {Stats.PremiumExpired} · Новых за 7 дн.: {Stats.Registrations7d}\n" +
        $"Платежей: {Stats.PaymentsSucceeded} · Выручка: {Stats.RevenueRub:N0} ₽ · Устройств: {Stats.Devices} · Инструментов: {Stats.ToolsPublished}";
    public string Query { get => _query; set => Set(ref _query, value); }
    public string GrantDays { get => _grantDays; set => Set(ref _grantDays, value); }
    public AdminUserDto? Selected { get => _sel; set { Set(ref _sel, value); BlockCommand.Notify(); GrantCommand.Notify(); Raise(nameof(BlockText)); } }
    public string BlockText => Selected?.IsBlocked == true ? "Разблокировать" : "Заблокировать";
    public RelayCommand SearchCommand { get; } public RelayCommand BlockCommand { get; } public RelayCommand GrantCommand { get; }
    public async Task Load() {
        Stats = await Services.Api.AdminStats(); await Search();
        Audit.Clear(); foreach (var a in await Services.Api.AdminAudit()) Audit.Add(a);
    }
    async Task Search() {
        Users.Clear(); foreach (var u in await Services.Api.AdminUsers(Query)) Users.Add(u);
        Stats = await Services.Api.AdminStats();
    }
}
