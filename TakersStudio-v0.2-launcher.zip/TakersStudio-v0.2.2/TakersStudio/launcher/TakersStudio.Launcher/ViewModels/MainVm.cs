using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Threading;
using TakersStudio.Launcher.Core;
namespace TakersStudio.Launcher.ViewModels;

public class MainVm : ObservableObject {
    MeDto? _me; bool _loggedIn, _ready; object? _page; ReleaseDto? _update; string _nav = "home";
    readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromMinutes(5) };

    public AuthVm Auth { get; }
    public HomeVm Home { get; private set; } = null!;
    public CatalogVm Catalog { get; private set; } = null!;
    public PremiumVm Premium { get; private set; } = null!;
    public AccountVm Account { get; private set; } = null!;
    public SettingsVm Settings { get; private set; } = null!;
    public LogsVm Logs { get; private set; } = null!;
    public AdminVm Admin { get; private set; } = null!;

    public MainVm() {
        Auth = new AuthVm(this);
        NavCommand = new RelayCommand(p => Navigate((string)p!));
        LogoutCommand = new RelayCommand(async _ => await Logout());
        InstallUpdateCommand = new RelayCommand(async _ => { if (_update != null) await Updater.DownloadAndRun(_update); });
        Services.Api.SessionLost += () => Application.Current.Dispatcher.Invoke(ResetToLogin);
        _timer.Tick += async (_, _) => { try { if (LoggedIn) await RefreshMe(); } catch { } };
    }

    public bool LoggedIn { get => _loggedIn; set { if (Set(ref _loggedIn, value)) Raise(nameof(NotLoggedIn)); } }
    public bool NotLoggedIn => !LoggedIn && _ready;
    public bool Ready { get => _ready; set { Set(ref _ready, value); Raise(nameof(NotLoggedIn)); } }
    public MeDto? Me { get => _me; set { Set(ref _me, value); Raise(nameof(IsAdmin)); Raise(nameof(UserTitle)); Raise(nameof(SubscriptionText)); } }
    public bool IsAdmin => Me?.Role is "Admin" or "Owner";
    public string UserTitle => Me == null ? "" : (string.IsNullOrWhiteSpace(Me.DisplayName) ? Me.Email : Me.DisplayName!);
    public string SubscriptionText => Me == null ? "" : Me.Premium && Me.PremiumUntil is { } t
        ? $"Premium активен до {t.ToLocalTime():dd.MM.yyyy HH:mm}" : "Premium не активен";
    public object? Page { get => _page; set => Set(ref _page, value); }
    public string Nav { get => _nav; set => Set(ref _nav, value); }
    public bool HasUpdate => _update != null;
    public string UpdateText => _update == null ? "" : $"Доступна версия {_update.Version}. {_update.Changelog}";

    public RelayCommand NavCommand { get; }
    public RelayCommand LogoutCommand { get; }
    public RelayCommand InstallUpdateCommand { get; }

    public async Task Init() {
        Services.Host.Discover();
        Services.Log.Info($"Запуск TakersStudio {Services.AppVersion}");
        try { if (await Services.Api.TryRestore()) await OnLoggedIn(); } catch (Exception ex) { Errors.Handle(ex); }
        Ready = true;
    }

    public async Task OnLoggedIn() {
        Me = await Services.Api.Me();
        Home = new HomeVm(this); Catalog = new CatalogVm(this); Premium = new PremiumVm(this);
        Account = new AccountVm(this); Settings = new SettingsVm(this); Logs = new LogsVm(); Admin = new AdminVm(this);
        LoggedIn = true; Navigate("home");
        _timer.Start();
        await Catalog.Load();
        if (Services.Settings.CheckUpdates) await CheckUpdate(false);
    }

    public void Navigate(string name) {
        Nav = name;
        Page = name switch {
            "catalog" => Catalog, "premium" => Premium, "account" => Account, "settings" => Settings,
            "logs" => Logs, "admin" when IsAdmin => Admin, _ => Home };
        _ = Reload(name);
    }
    async Task Reload(string name) {
        try {
            switch (name) {
                case "catalog": await Catalog.Load(); break;
                case "premium": await Premium.Load(); break;
                case "account": await Account.Load(); break;
                case "admin": await Admin.Load(); break;
            }
        } catch (Exception ex) { Errors.Handle(ex); }
    }

    public async Task RefreshMe() { Me = await Services.Api.Me(); }

    public async Task CheckUpdate(bool manual) {
        try {
            var rel = await Services.Api.LatestRelease();
            if (rel != null && Updater.IsNewer(rel.Version)) {
                _update = rel; Raise(nameof(HasUpdate)); Raise(nameof(UpdateText));
                Services.Notify.Show($"Доступно обновление {rel.Version}");
            } else if (manual) Services.Notify.Show("У вас последняя версия");
        } catch (Exception ex) { if (manual) Errors.Handle(ex); else Services.Log.Warn("Проверка обновлений не удалась: " + ex.Message); }
    }

    public async Task Logout() {
        await Services.Host.StopAll();
        await Services.Api.Logout();
        ResetToLogin();
    }
    void ResetToLogin() { _timer.Stop(); LoggedIn = false; Me = null; Page = null; Auth.Reset(); }
}

public class AuthVm : ObservableObject {
    readonly MainVm _main; bool _reg, _busy; string _email = "", _name = "", _error = "";
    public AuthVm(MainVm m) {
        _main = m;
        SubmitCommand = new RelayCommand(async _ => await Submit());
        ToggleCommand = new RelayCommand(_ => { IsRegister = !IsRegister; Error = ""; });
    }
    public string Email { get => _email; set => Set(ref _email, value); }
    public string Name { get => _name; set => Set(ref _name, value); }
    public string Password { get; set; } = "";
    public string Password2 { get; set; } = "";
    public bool IsRegister { get => _reg; set { Set(ref _reg, value); Raise(nameof(Title)); Raise(nameof(SubmitText)); Raise(nameof(ToggleText)); } }
    public string Error { get => _error; set => Set(ref _error, value); }
    public bool Busy { get => _busy; set => Set(ref _busy, value); }
    public string Title => IsRegister ? "Регистрация" : "Вход";
    public string SubmitText => IsRegister ? "Создать аккаунт" : "Войти";
    public string ToggleText => IsRegister ? "Уже есть аккаунт? Войти" : "Нет аккаунта? Зарегистрироваться";
    public RelayCommand SubmitCommand { get; }
    public RelayCommand ToggleCommand { get; }
    public event Action? ClearPasswords;
    public void Reset() { Password = ""; Password2 = ""; Error = ""; ClearPasswords?.Invoke(); }

    async Task Submit() {
        Error = "";
        if (string.IsNullOrWhiteSpace(Email) || string.IsNullOrEmpty(Password)) { Error = "Введите почту и пароль"; return; }
        if (IsRegister) {
            if (Password.Length < 8) { Error = "Пароль должен быть не короче 8 символов"; return; }
            if (Password != Password2) { Error = "Пароли не совпадают"; return; }
        }
        Busy = true;
        try {
            if (IsRegister) await Services.Api.Register(Email.Trim(), Password, string.IsNullOrWhiteSpace(Name) ? null : Name.Trim());
            await Services.Api.Login(Email.Trim(), Password);
            await _main.OnLoggedIn();
            Password = ""; Password2 = ""; ClearPasswords?.Invoke();
        } catch (ApiException ex) { Error = ex.Message; }
        catch (Exception ex) { Errors.Handle(ex); }
        finally { Busy = false; }
    }
}
