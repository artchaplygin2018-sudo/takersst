using System.Collections.ObjectModel;
using System.Text.Json;
namespace TakersStudio.Launcher.Core;

public static class Services {
    public static readonly string DataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "TakersStudio");
    public static readonly Logger Log = new();
    public static readonly Notifier Notify = new();
    public static readonly AppSettings Settings = AppSettings.Load();
    public static readonly Api Api = new(Settings.ApiBaseUrl);
    public static readonly ToolHost Host = new();
    public static string AppVersion => typeof(Services).Assembly.GetName().Version?.ToString(3) ?? "0.0.0";
}

public class AppSettings {
    public string ApiBaseUrl { get; set; } = "http://localhost:5000";
    public bool CheckUpdates { get; set; } = true;
    public bool Notifications { get; set; } = true;
    static string FilePath => Path.Combine(Services.DataDir, "settings.json");
    public static AppSettings Load() {
        try { if (File.Exists(FilePath)) return JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath)) ?? new(); } catch { }
        return new();
    }
    public void Save() { Directory.CreateDirectory(Services.DataDir); File.WriteAllText(FilePath, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true })); }
}

public class Logger {
    public ObservableCollection<string> Lines { get; } = new();
    readonly object _l = new();
    public void Info(string m) => Write("INFO", m);
    public void Warn(string m) => Write("WARN", m);
    public void Error(string m) => Write("ERROR", m);
    void Write(string level, string m) {
        var line = $"{DateTime.Now:HH:mm:ss} [{level}] {m}";
        try {
            lock (_l) {
                var dir = Path.Combine(Services.DataDir, "logs"); Directory.CreateDirectory(dir);
                File.AppendAllText(Path.Combine(dir, $"launcher-{DateTime.Now:yyyyMMdd}.log"), line + Environment.NewLine);
            }
        } catch { }
        System.Windows.Application.Current?.Dispatcher.BeginInvoke(() => { Lines.Add(line); if (Lines.Count > 500) Lines.RemoveAt(0); });
    }
}

public record Toast(string Text, bool IsError);
public class Notifier {
    public ObservableCollection<Toast> Toasts { get; } = new();
    public void Show(string text, bool error = false) {
        if (!error && !Services.Settings.Notifications) return;
        System.Windows.Application.Current?.Dispatcher.BeginInvoke(async () => {
            var t = new Toast(text, error); Toasts.Add(t);
            await Task.Delay(error ? 7000 : 4000); Toasts.Remove(t);
        });
    }
}
