using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
namespace TakersStudio.Launcher.Core;

public abstract class ObservableObject : INotifyPropertyChanged {
    public event PropertyChangedEventHandler? PropertyChanged;
    protected bool Set<T>(ref T field, T value, [CallerMemberName] string? name = null) {
        if (EqualityComparer<T>.Default.Equals(field, value)) return false;
        field = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name)); return true;
    }
    protected void Raise([CallerMemberName] string? name = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}

public class RelayCommand : ICommand {
    readonly Func<object?, Task>? _async; readonly Action<object?>? _sync; readonly Func<object?, bool>? _can; bool _busy;
    public RelayCommand(Action<object?> run, Func<object?, bool>? can = null) { _sync = run; _can = can; }
    public RelayCommand(Func<object?, Task> run, Func<object?, bool>? can = null) { _async = run; _can = can; }
    public event EventHandler? CanExecuteChanged;
    public bool CanExecute(object? p) => !_busy && (_can?.Invoke(p) ?? true);
    public async void Execute(object? p) {
        try {
            if (_async != null) { _busy = true; Notify(); await _async(p); }
            else _sync!(p);
        } catch (Exception ex) { Errors.Handle(ex); }
        finally { if (_async != null) { _busy = false; Notify(); } }
    }
    public void Notify() => System.Windows.Application.Current?.Dispatcher.Invoke(() => CanExecuteChanged?.Invoke(this, EventArgs.Empty));
}

public static class Errors {
    /// <summary>Единая обработка: в журнал (без секретов) и понятное уведомление пользователю.</summary>
    public static void Handle(Exception ex) {
        Services.Log.Error(ex.GetType().Name + ": " + ex.Message);
        var msg = ex switch {
            ApiException a => a.Message,
            HttpRequestException => "Нет связи с сервером. Проверьте интернет и адрес сервера в настройках.",
            TaskCanceledException => "Сервер не ответил вовремя.",
            _ => "Произошла ошибка: " + ex.Message
        };
        Services.Notify.Show(msg, true);
    }
}
