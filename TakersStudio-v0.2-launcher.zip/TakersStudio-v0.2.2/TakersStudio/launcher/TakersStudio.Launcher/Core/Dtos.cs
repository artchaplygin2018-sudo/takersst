namespace TakersStudio.Launcher.Core;

public record MeDto(Guid Id, string Email, string? DisplayName, string Role, bool Premium, DateTime? PremiumUntil, bool TrialUsed);
public record ToolDto(string Slug, string Name, string Description, string Category, string? Icon, string Version, bool PremiumOnly, bool Locked);
public record PlanDto(int Id, string Name, int Days, decimal Rub, bool IsTrial);
public record PaymentDto(Guid Id, int PlanId, decimal Rub, string Status, DateTime CreatedAt, DateTime? PaidAt);
public record DeviceDto(Guid Id, string Name, string OsVersion, string AppVersion, DateTime LastSeen);
public record SubEventDto(string Kind, int? Days, DateTime? PremiumUntilAfter, DateTime CreatedAt);
public record ReleaseDto(string Version, string Changelog, string DownloadUrl, string Sha256, long SizeBytes, DateTime CreatedAt);
public record CreatePaymentResult(Guid PaymentId, string? ConfirmationUrl);
public record PaymentStatusDto(Guid Id, string Status, DateTime? PaidAt);
public record AdminStatsDto(int Users, int PremiumActive, int PremiumExpired, int Registrations7d, int PaymentsSucceeded, decimal RevenueRub, int Devices, int ToolsPublished);
public record AdminUserDto(Guid Id, string Email, string? DisplayName, string Role, bool IsBlocked, DateTime? PremiumUntil, DateTime CreatedAt);
public record AuditDto(long Id, Guid? ActorId, string Action, string? Target, string? Details, DateTime CreatedAt);
