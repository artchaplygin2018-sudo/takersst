using System.Reflection;
using TakersStudio.Sdk;
namespace TakersStudio.Launcher.Core;

/// <summary>Находит и запускает модули-инструменты из папки modules/ рядом с программой. Никакой имитации: нет .dll — нет запуска.</summary>
public class ToolHost {
    readonly Dictionary<string, IToolModule> _modules = new(StringComparer.OrdinalIgnoreCase);
    public string ModulesDir => Path.Combine(AppContext.BaseDirectory, "modules");
    public IReadOnlyDictionary<string, IToolModule> Modules => _modules;

    public void Discover() {
        _modules.Clear();
        if (!Directory.Exists(ModulesDir)) { Directory.CreateDirectory(ModulesDir); return; }
        foreach (var dll in Directory.EnumerateFiles(ModulesDir, "*.dll", SearchOption.AllDirectories)) {
            try {
                var asm = Assembly.LoadFrom(dll);
                foreach (var t in asm.GetTypes().Where(t => typeof(IToolModule).IsAssignableFrom(t) && t is { IsClass: true, IsAbstract: false })) {
                    if (Activator.CreateInstance(t) is IToolModule m) { _modules[m.Slug] = m; Services.Log.Info($"Модуль загружен: {m.Slug} v{m.Version}"); }
                }
            } catch (Exception ex) { Services.Log.Error($"Не удалось загрузить модуль {Path.GetFileName(dll)}: {ex.Message}"); }
        }
    }
    public IToolModule? Find(string slug) => _modules.TryGetValue(slug, out var m) ? m : null;
    public async Task StopAll() { foreach (var m in _modules.Values.Where(m => m.State is ToolState.Running or ToolState.Starting)) { try { await m.StopAsync(); } catch { } } }
}

public class ToolContext(string slug) : IToolContext {
    public string DataDir { get; } = Directory.CreateDirectory(Path.Combine(Services.DataDir, "tools", slug)).FullName;
    public IReadOnlyDictionary<string, string> Settings { get; } = new Dictionary<string, string>();
    public void Log(string message) => Services.Log.Info($"[{slug}] {message}");
}
