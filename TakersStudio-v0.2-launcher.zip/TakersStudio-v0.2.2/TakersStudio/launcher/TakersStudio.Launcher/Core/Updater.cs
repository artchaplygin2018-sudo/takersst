using System.Diagnostics;
using System.Security.Cryptography;
namespace TakersStudio.Launcher.Core;

public static class Updater {
    public static bool IsNewer(string remote) =>
        Version.TryParse(remote, out var r) && Version.TryParse(Services.AppVersion, out var l) && r > l;

    /// <summary>Скачивает установщик, сверяет SHA-256 с значением от Backend и только потом запускает.</summary>
    public static async Task DownloadAndRun(ReleaseDto rel) {
        if (!Uri.TryCreate(rel.DownloadUrl, UriKind.Absolute, out var uri) || uri.Scheme != Uri.UriSchemeHttps)
            throw new InvalidOperationException("Ссылка на обновление небезопасна (нужен https).");
        var path = Path.Combine(Path.GetTempPath(), $"TakersStudio-Setup-{rel.Version}.exe");
        using (var http = new HttpClient { Timeout = TimeSpan.FromMinutes(10) })
        using (var s = await http.GetStreamAsync(uri))
        using (var f = File.Create(path)) await s.CopyToAsync(f);
        string hash;
        using (var f = File.OpenRead(path)) hash = Convert.ToHexString(await SHA256.HashDataAsync(f));
        if (!hash.Equals(rel.Sha256, StringComparison.OrdinalIgnoreCase)) {
            File.Delete(path);
            throw new InvalidOperationException("Контрольная сумма обновления не совпала. Установка отменена.");
        }
        Services.Log.Info("Обновление проверено, запуск установщика " + rel.Version);
        await Services.Host.StopAll();
        Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
        System.Windows.Application.Current.Shutdown();
    }
}
