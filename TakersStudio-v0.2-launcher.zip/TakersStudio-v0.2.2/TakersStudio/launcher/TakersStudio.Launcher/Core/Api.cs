using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
namespace TakersStudio.Launcher.Core;

public class ApiException(string message, int status) : Exception(message) { public int Status { get; } = status; }

record TokenResp(string AccessToken, string RefreshToken, Guid? DeviceId);
record SessionData(string RefreshToken, Guid? DeviceId);

/// <summary>Клиент Backend. Токен доступа живёт только в памяти; refresh-токен хранится зашифрованным (DPAPI, привязан к пользователю Windows).</summary>
public class Api {
    static readonly JsonSerializerOptions J = new(JsonSerializerDefaults.Web);
    HttpClient _http; string? _access; string? _refresh; Guid? _deviceId;
    readonly SemaphoreSlim _refreshLock = new(1, 1);
    static string SessionFile => Path.Combine(Services.DataDir, "session.bin");

    public Api(string baseUrl) { _http = Make(baseUrl); }
    public event Action? SessionLost;
    public bool HasSession => _refresh != null;

    static HttpClient Make(string baseUrl) {
        var c = new HttpClient { BaseAddress = new Uri(baseUrl.TrimEnd('/') + "/"), Timeout = TimeSpan.FromSeconds(20) };
        c.DefaultRequestHeaders.UserAgent.ParseAdd("TakersStudioLauncher/" + Services.AppVersion);
        return c;
    }
    public void SetBaseUrl(string url) { _http = Make(url); }

    // ---------- сессия ----------
    public async Task Register(string email, string password, string? name) =>
        await Send<object>(HttpMethod.Post, "api/auth/register", new { email, password, displayName = name }, auth: false);

    public async Task Login(string email, string password) {
        var dev = new { name = Environment.MachineName, osVersion = Environment.OSVersion.VersionString, appVersion = Services.AppVersion };
        var t = await Send<TokenResp>(HttpMethod.Post, "api/auth/login", new { email, password, device = dev }, auth: false);
        _access = t.AccessToken; _refresh = t.RefreshToken; _deviceId = t.DeviceId; SaveSession();
    }

    public async Task<bool> TryRestore() {
        try {
            if (!File.Exists(SessionFile)) return false;
            var plain = ProtectedData.Unprotect(File.ReadAllBytes(SessionFile), null, DataProtectionScope.CurrentUser);
            var s = JsonSerializer.Deserialize<SessionData>(plain, J)!;
            _refresh = s.RefreshToken; _deviceId = s.DeviceId;
            return await Refresh();
        } catch { ClearSession(); return false; }
    }

    public async Task Logout() {
        try { if (_refresh != null) await Send<object>(HttpMethod.Post, "api/auth/logout", new { refreshToken = _refresh }, auth: false); } catch { }
        ClearSession();
    }

    void SaveSession() {
        Directory.CreateDirectory(Services.DataDir);
        var bytes = JsonSerializer.SerializeToUtf8Bytes(new SessionData(_refresh!, _deviceId), J);
        File.WriteAllBytes(SessionFile, ProtectedData.Protect(bytes, null, DataProtectionScope.CurrentUser));
    }
    void ClearSession() { _access = null; _refresh = null; _deviceId = null; try { File.Delete(SessionFile); } catch { } }
    public Guid? CurrentDeviceId => _deviceId;

    async Task<bool> Refresh() {
        await _refreshLock.WaitAsync();
        try {
            if (_refresh == null) return false;
            var req = new HttpRequestMessage(HttpMethod.Post, "api/auth/refresh") { Content = JsonContent.Create(new { refreshToken = _refresh }, options: J) };
            var res = await _http.SendAsync(req);
            if (!res.IsSuccessStatusCode) {
                if (res.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden) ClearSession();
                return false;
            }
            var t = (await res.Content.ReadFromJsonAsync<TokenResp>(J))!;
            _access = t.AccessToken; _refresh = t.RefreshToken; SaveSession(); return true;
        } finally { _refreshLock.Release(); }
    }

    // ---------- запросы ----------
    public async Task<T> Send<T>(HttpMethod m, string path, object? body = null, bool auth = true) {
        var res = await Raw(m, path, body, auth);
        if (res.StatusCode == HttpStatusCode.Unauthorized && auth) {
            if (await Refresh()) res = await Raw(m, path, body, auth);
            else { SessionLost?.Invoke(); throw new ApiException("Сессия истекла. Войдите снова.", 401); }
        }
        if (!res.IsSuccessStatusCode) {
            string msg = "Ошибка сервера (" + (int)res.StatusCode + ")";
            try { var e = await res.Content.ReadFromJsonAsync<JsonElement>(J); if (e.TryGetProperty("error", out var p)) msg = p.GetString() ?? msg; } catch { }
            if (res.StatusCode == HttpStatusCode.TooManyRequests) msg = "Слишком много попыток. Подождите минуту.";
            throw new ApiException(msg, (int)res.StatusCode);
        }
        if (typeof(T) == typeof(object) || res.StatusCode == HttpStatusCode.NoContent) return default!;
        return (await res.Content.ReadFromJsonAsync<T>(J))!;
    }
    async Task<HttpResponseMessage> Raw(HttpMethod m, string path, object? body, bool auth) {
        var req = new HttpRequestMessage(m, path);
        if (body != null) req.Content = JsonContent.Create(body, options: J);
        if (auth && _access != null) req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _access);
        return await _http.SendAsync(req);
    }
    public Task<T> Get<T>(string path) => Send<T>(HttpMethod.Get, path);

    // удобные обёртки
    public Task<MeDto> Me() => Get<MeDto>("api/me");
    public Task<List<ToolDto>> Tools() => Get<List<ToolDto>>("api/tools");
    public Task<List<PlanDto>> Plans() => Send<List<PlanDto>>(HttpMethod.Get, "api/plans", auth: false);
    public Task<List<PaymentDto>> Payments() => Get<List<PaymentDto>>("api/me/payments");
    public Task<List<DeviceDto>> Devices() => Get<List<DeviceDto>>("api/me/devices");
    public Task<List<SubEventDto>> SubscriptionHistory() => Get<List<SubEventDto>>("api/me/subscription-history");
    public Task RevokeDevice(Guid id) => Send<object>(HttpMethod.Delete, $"api/me/devices/{id}");
    public Task<CreatePaymentResult> CreatePayment(int planId) => Send<CreatePaymentResult>(HttpMethod.Post, "api/payments", new { planId });
    public Task<PaymentStatusDto> PaymentStatus(Guid id) => Get<PaymentStatusDto>($"api/payments/{id}");
    public Task ToolAccess(string slug) => Send<object>(HttpMethod.Get, $"api/tools/{Uri.EscapeDataString(slug)}/access");
    public async Task<ReleaseDto?> LatestRelease() {
        try { return await Send<ReleaseDto>(HttpMethod.Get, "api/releases/latest", auth: false); }
        catch (ApiException e) when (e.Status == 404) { return null; }
    }
    public Task<AdminStatsDto> AdminStats() => Get<AdminStatsDto>("api/admin/stats");
    public Task<List<AdminUserDto>> AdminUsers(string? q) => Get<List<AdminUserDto>>("api/admin/users?q=" + Uri.EscapeDataString(q ?? ""));
    public Task AdminBlock(Guid id, bool blocked) => Send<object>(HttpMethod.Post, $"api/admin/users/{id}/block?blocked={blocked.ToString().ToLowerInvariant()}");
    public Task AdminGrant(Guid id, int days) => Send<object>(HttpMethod.Post, $"api/admin/users/{id}/grant", new { days });
    public Task<List<AuditDto>> AdminAudit() => Get<List<AuditDto>>("api/admin/audit");
}
