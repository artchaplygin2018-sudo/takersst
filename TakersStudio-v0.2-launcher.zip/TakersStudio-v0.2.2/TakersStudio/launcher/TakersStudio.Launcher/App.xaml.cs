using System.Windows;
using TakersStudio.Launcher.Core;
namespace TakersStudio.Launcher;

public partial class App : Application {
    protected override void OnStartup(StartupEventArgs e) {
        // Необработанные ошибки не должны молча закрывать программу
        DispatcherUnhandledException += (_, a) => { Errors.Handle(a.Exception); a.Handled = true; };
        TaskScheduler.UnobservedTaskException += (_, a) => { Services.Log.Error("Task: " + a.Exception.GetBaseException().Message); a.SetObserved(); };
        base.OnStartup(e);
    }
    protected override async void OnExit(ExitEventArgs e) { try { await Services.Host.StopAll(); } catch { } base.OnExit(e); }
}
