using System.Windows;
using TakersStudio.Launcher.ViewModels;
namespace TakersStudio.Launcher;

public partial class MainWindow : Window {
    public MainWindow() {
        InitializeComponent();
        var vm = new MainVm(); DataContext = vm;
        Loaded += async (_, _) => await vm.Init();
    }
    void Min_Click(object s, RoutedEventArgs e) => WindowState = WindowState.Minimized;
    void Max_Click(object s, RoutedEventArgs e) => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
    void Close_Click(object s, RoutedEventArgs e) => Close();
}
