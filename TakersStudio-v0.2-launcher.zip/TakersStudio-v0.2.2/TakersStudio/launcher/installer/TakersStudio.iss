; Inno Setup (https://jrsoftware.org/isdl.php). Сначала выполните build.ps1.
[Setup]
AppName=TakersStudio
AppVersion=0.1.0
AppPublisher=TakersStudio
DefaultDirName={autopf}\TakersStudio
DefaultGroupName=TakersStudio
OutputDir=..\dist
OutputBaseFilename=TakersStudio-Setup-0.1.0
SetupIconFile=..\TakersStudio.Launcher\Assets\app.ico
UninstallDisplayIcon={app}\TakersStudio.exe
WizardStyle=modern
WizardImageFile=wiz_large.bmp,wiz_large2x.bmp
WizardSmallImageFile=wiz_small.bmp,wiz_small2x.bmp
Compression=lzma2
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=lowest

[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"

[Files]
Source: "..\publish\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion

[Icons]
Name: "{group}\TakersStudio"; Filename: "{app}\TakersStudio.exe"
Name: "{autodesktop}\TakersStudio"; Filename: "{app}\TakersStudio.exe"

[Run]
Filename: "{app}\TakersStudio.exe"; Description: "Запустить TakersStudio"; Flags: nowait postinstall skipifsilent
