# Сборка TakersStudio Launcher. Запускать в PowerShell из папки launcher.
# Требуется: .NET 10 SDK (https://dotnet.microsoft.com/download/dotnet/10.0)
$ErrorActionPreference = "Stop"
$out = Join-Path $PSScriptRoot "publish"
if (Test-Path $out) { Remove-Item $out -Recurse -Force }
dotnet publish "$PSScriptRoot\TakersStudio.Launcher\TakersStudio.Launcher.csproj" `
  -c Release -r win-x64 --self-contained true `
  -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o $out
if ($LASTEXITCODE -ne 0) { throw "Сборка не удалась" }
New-Item -ItemType Directory -Force -Path (Join-Path $out "modules") | Out-Null
Write-Host "Готово: $out\TakersStudio.exe"
Write-Host "Установщик: откройте installer\TakersStudio.iss в Inno Setup и нажмите Compile."
