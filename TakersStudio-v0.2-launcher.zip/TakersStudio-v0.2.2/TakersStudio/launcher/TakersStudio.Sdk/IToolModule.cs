namespace TakersStudio.Sdk;

public enum ToolState { Stopped, Starting, Running, Error }

/// <summary>Описание настройки, которую модуль показывает в карточке (пока только текст/число/флажок).</summary>
public record ToolSetting(string Key, string Title, string Type /* text|number|bool */, string DefaultValue);

public interface IToolContext {
    /// <summary>Папка для данных модуля (создаётся лаунчером).</summary>
    string DataDir { get; }
    IReadOnlyDictionary<string, string> Settings { get; }
    void Log(string message);
}

/// <summary>
/// Контракт модуля-инструмента. Модуль — это .dll в папке modules/, содержащая публичный класс
/// с этим интерфейсом и конструктором без параметров. Slug должен совпадать со slug инструмента в каталоге Backend.
/// Лаунчер НЕ запускает модуль без серверного разрешения (/api/tools/{slug}/access).
/// </summary>
public interface IToolModule {
    string Slug { get; }
    string Version { get; }
    ToolState State { get; }
    event Action<ToolState>? StateChanged;
    IReadOnlyList<ToolSetting> Settings { get; }
    Task StartAsync(IToolContext context, CancellationToken ct);
    Task StopAsync();
}
