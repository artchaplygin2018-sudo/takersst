$ErrorActionPreference = "Stop"

Write-Host "Building TakersStudio..."

$out = Join-Path $PSScriptRoot "publish"

if (Test-Path $out) {
    Remove-Item $out -Recurse -Force
}

dotnet publish "$PSScriptRoot\TakersStudio.Launcher\TakersStudio.Launcher.csproj" `
    -c Release `
    -r win-x64 `
    --self-contained true `
    -p:PublishSingleFile=true `
    -p:IncludeNativeLibrariesForSelfExtract=true `
    -o $out

if ($LASTEXITCODE -ne 0) {
    throw "Build failed"
}

New-Item -ItemType Directory -Force -Path (Join-Path $out "modules") | Out-Null

Write-Host "Build completed!"
Write-Host "Application: $out\TakersStudio.exe"
Write-Host "Installer script: installer\TakersStudio.iss"